function completar(){
    // En el select de estudios agregar 2 opciones: Master y Doctorado
    var opt = new Option("Master", "master");
    formulario.estudiosTxt.options[formulario.estudiosTxt.options.length] = opt;
    opt = new Option("Doctorado", "doctorado");
    formulario.estudiosTxt.options[formulario.estudiosTxt.options.length] = opt;

    // En el select de cursos agregar Java y Python
    opt = new Option("Java", "java");
    formulario.cursosTxt.options[formulario.cursosTxt.options.length] = opt;
    opt = new Option("Python", "python");
    formulario.cursosTxt.options[formulario.cursosTxt.options.length] = opt;
}

function mostrar(){
    // Cancelar el evento submit
    event.preventDefault();

    // Mostrar en consola los datos introducidos en el formulario
    console.log("Nombre: " + document.getElementById("nombreTxt").value);
    console.log("Apellido: " + formulario.apellidoTxt.value);
    console.log("Edad: " + formulario.edadTxt.value);
    console.log("Email: " + formulario.emailTxt.value);
    console.log("Sitio Web: " + formulario.urlTxt.value);
    console.log("Fecha de nacimiento: " + formulario.fechaTxt.value);
    console.log("Sexo: " + formulario.sexoTxt.value);
    console.log("Estudios: " + 
        formulario.estudiosTxt.options[
            formulario.estudiosTxt.selectedIndex].text);
    
    for (var i in formulario.cursosTxt.options){
        if (formulario.cursosTxt.options[i].selected){
            console.log("Curso realizado: " + formulario.cursosTxt.options[i].text);
        }
    }
}