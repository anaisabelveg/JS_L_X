var texto = "Hola";
var edad = 38;
var casado = true;
var miVariable;
var hoy = new Date();
var division = 7 / 'a';

document.write(texto + " tipo: " + typeof(texto) + "<br/>");
document.write(edad + " tipo: " + typeof(edad) + "<br/>");
document.write(casado + " tipo: " + typeof(casado) + "<br/>");
document.write(miVariable + " tipo: " + typeof(miVariable) + "<br/>");
document.write(hoy + " tipo: " + typeof(hoy) + "<br/>");
document.write(division + " tipo: " + typeof(division) + "<br/>");