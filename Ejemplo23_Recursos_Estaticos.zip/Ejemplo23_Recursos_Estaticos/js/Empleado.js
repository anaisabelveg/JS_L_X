class Empleado{

    // Propiedades de instancia, cada objeto mantiene una copia de estas propiedades
    #numEmpleado;
    #nombre;
    #sueldo;

    // Propiedad de clase, solo existe una copia y reside en la clase
    static #contador = 0;

    constructor(nombre, sueldo){
        Empleado.#contador++;

        this.#numEmpleado = Empleado.#contador;
        this.#nombre = nombre;
        this.#sueldo = sueldo;
    }

    // Metodo pertenece a la clase
    static getContador(){
        return Empleado.#contador;
    }

    getNumEmpleado(){
        return this.#numEmpleado;
    }

    setNumEmpleado(numEmpleado){
        this.#numEmpleado = numEmpleado;
    }

    getNombre(){
        return this.#nombre;
    }

    setNombre(nombre){
        this.#nombre = nombre;
    }

    getSueldo(){
        return this.#sueldo;
    }

    setSueldo(sueldo){
        this.#sueldo = sueldo;
    }

    mostrarInfo(){
        return "Numero empleado: " + this.#numEmpleado + 
            " Nombre: " + this.#nombre + " Sueldo: " + this.#sueldo;
    }

}