function cambiarColor(event){

    switch (event.target.id) {
        case "btn1":
            // Ha pulsado el boton rojo
            document.getElementById("btn1").className = "rojo"
            break;

        case "btn2":
            // Ha pulsado el boton verde
            document.getElementById("btn2").className = "verde"
            break;
        
        case "btn3":
            // Ha pulsado el boton azul
            document.getElementById("btn3").className = "azul"
            break;
   }

}