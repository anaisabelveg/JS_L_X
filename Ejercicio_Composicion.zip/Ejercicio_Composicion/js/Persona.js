class Persona{

    // propiedades privadas
    #nombre;
    #edad;
    #direccion;

    // constructor
    constructor(nombre, edad, direccion){
        this.setNombre(nombre);
        this.setEdad(edad);
        this.setDireccion(direccion);
    }

    getNombre(){
        return this.#nombre;
    }

    setNombre(nombre){
        this.#nombre = nombre;
    }

    getEdad(){
        return this.#edad;
    }

    setEdad(edad){
        if (edad > 0){
            this.#edad = edad;
        }
    }

    getDireccion(){
        return this.#direccion;
    }

    setDireccion(direccion){
        this.#direccion = direccion;
    }

    mostrarInfo(){
        return "Nombre: " + this.#nombre + " Edad: " + this.#edad +
            " Direccion: " + this.#direccion.mostrarInfo();
    }
}