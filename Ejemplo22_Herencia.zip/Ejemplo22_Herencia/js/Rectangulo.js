class Rectangulo extends Figura{

    base;
    altura;

    constructor(x, y, base, altura){
        super(x,y);   // Llamamos al constructor de la superclase
        this.base = base;
        this.altura = altura;
    }

    // Sobreescribir el metodo area
    area(){
        return this.base * this.altura;
    }

    mostrarDatos(){
        // super. es el puntero super que apunta a los recursos de la superclase
        return super.mostrarDatos() + 
            " base: " + this.base + " altura: " + this.altura;
    }
  

}