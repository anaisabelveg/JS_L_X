class Circulo extends Figura{

    radio;

    constructor(x, y, radio){
        super(x,y);  // invocamos al constructor de la superclase
        this.radio = radio;
    }

    // sobreescrir el metodo area
    area(){
        return Math.PI * Math.pow(this.radio, 2);
    }

    // sobreescrir el metodo mostrarDatos
    mostrarDatos(){
        return super.mostrarDatos() + " radio: " + this.radio;
    }

}