class Alumno{

    // propiedades, atributos, campos, caracteristicas
    nombre;
    apellido;
    nota;

    // Constructor
    constructor(nombre, apellido, nota){
        // Los parametros que hemos recibido en el constructor
        // los asignamos a las propiedades del objeto
        this.nombre = nombre;
        this.apellido = apellido;
        this.nota = nota;
    }

    // acciones, metodos
    mostrarInformacion(){
        return "Nombre: " + this.nombre +
        " Apellido: " + this.apellido + " Nota: " + this.nota;
    }
}