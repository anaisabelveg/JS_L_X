class Producto{

    // Propiedades
    id;
    descripcion;
    precio;

    // Constructor
    constructor(id, descripcion, precio){
        this.id = id;
        this.descripcion = descripcion;
        this.precio = precio;
    }

    // Metodos
    mostrarInformacion(){
        return "ID: " + this.id + 
            " Descripcion: " + this.descripcion +
            " Precio: " + this.precio;
    }

}