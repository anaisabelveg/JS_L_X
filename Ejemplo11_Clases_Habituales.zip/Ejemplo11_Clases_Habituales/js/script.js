function fechas(){
    var hoy = new Date();
    document.write("getTime: " + hoy.getTime() + "<br/>");
    document.write("Diferencia horaria: " + hoy.getTimezoneOffset() + "<br/>");
    document.write("Dia de la semana: " + hoy.getDay() + "<br/>");
    document.write("Dia del mes: " + hoy.getDate() + "<br/>");
    document.write("Mes: " + hoy.getMonth() + "<br/>");
    document.write("Año: " + hoy.getYear() + "<br/>");
    document.write("Año completo: " + hoy.getFullYear() + "<br/>");
    document.write("Horas: " + hoy.getHours() + "<br/>");
    document.write("Minutos: " + hoy.getMinutes() + "<br/>");
    document.write("Segundos: " + hoy.getSeconds() + "<br/>");
    document.write("Milisegundos: " + hoy.getMilliseconds() + "<br/>");
}


function textos(){
    var texto = "Esto es un texto para probar las funciones String";
    document.write("Caracter a partir de unicode: " + String.fromCharCode(74) + "<br/>");
    document.write("charcode de la posicion 3: " + texto.charCodeAt(3) + "<br/>");
    document.write("posicion de a: " + texto.indexOf("a") + "<br/>");
    document.write("ultima posicion de a: " + texto.lastIndexOf("a") + "<br/>");
    document.write("substr 3,6: " + texto.substr(3,6) + "<br/>");
    document.write("slice 3,6: " + texto.slice(3,6) + "<br/>");
    document.write("slice 3: " + texto.slice(3) + "<br/>");
    document.write("substring 3,6: " + texto.substring(3,6) + "<br/>");
    document.write("minusculas: " + texto.toLowerCase() + "<br/>");
    document.write("mayusculas: " + texto.toUpperCase() + "<br/>");
}

function matematicas(){
    document.write("log 1000: " + Math.log(1000) + "<br/>");
    document.write("exp 3: " + Math.exp(3) + "<br/>");
    document.write("Raiz de 25: " + Math.sqrt(25) + "<br/>");
    document.write("Potencia 2 elevado 4: " + Math.pow(2,4) + "<br/>");
    document.write("Abs -6.565: " + Math.abs(-6.565) + "<br/>");
    document.write("redondeo baja -3.6543: " + Math.floor(-3.6543) + "<br/>");
    document.write("redondeo baja 3.6543: " + Math.floor(3.6543) + "<br/>");
    document.write("redondeo alta -3.6543: " + Math.ceil(-3.6543) + "<br/>");
    document.write("redondeo alta 3.6543: " + Math.ceil(3.6543) + "<br/>");
    document.write("redondeo medio 3.6543: " + Math.round(3.6543) + "<br/>");
    document.write("redondeo medio 3.1543: " + Math.round(3.1543) + "<br/>");
    document.write("coseno de 100: " + Math.cos(100) + "<br/>");
    document.write("Max: " + Math.max(8,3,5,1,9,2) + "<br/>");
    document.write("Min: " + Math.min(8,3,5,1,9,2) + "<br/>");
    document.write("PI: " + Math.PI + "<br/>");
    document.write("E: " + Math.E + "<br/>");

    with(Math){
        document.write("Area: " + (PI * pow(8, 2)) + "<br/>");
    }
}

