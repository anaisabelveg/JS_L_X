function cargarProvincias(){
    // Crear un array de provincias
    var arrayProvincias = new Array("Madrid", "Sevilla", "Toledo");

    // Recorrer el array y por cada provincia generamos un option
    for (var indice in arrayProvincias){
        document.getElementById("provincias").innerHTML +=
            "<option>" + arrayProvincias[indice] + "</option>";
    }
}

function cargarPoblaciones(){
    var seleccionado = document.getElementById("provincias").selectedIndex;
    var arrayPoblaciones = null;
    
    switch (seleccionado) {
        case 1:
            arrayPoblaciones = ["Getafe", "Parla", "Torrelodones"];
            break;
    
        case 2:
            arrayPoblaciones = ["Dos Hermanas", "Espartinas", "Los Palacios"];    
            break;
            
        case 3:
            arrayPoblaciones = ["Talavera", "Trillo", "Cebolla"];    
            break;               
    }

    // Limpiar todas las opciones anteriores
    document.getElementById("poblaciones").innerHTML = "<option>--selecciona--</option>";

    for(var indice in arrayPoblaciones){
        var opt = new Option(arrayPoblaciones[indice], indice);
        document.getElementById("poblaciones").options[parseInt(indice)+1] = opt;
    }
}